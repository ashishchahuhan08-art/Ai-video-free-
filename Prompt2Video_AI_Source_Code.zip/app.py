import os, uuid, subprocess, textwrap, shutil
from pathlib import Path
from flask import Flask, render_template, request, send_from_directory, flash, redirect, url_for
from PIL import Image, ImageDraw, ImageFont
import edge_tts
import asyncio
import imageio_ffmpeg

BASE = Path(__file__).resolve().parent
OUTPUT = BASE / "outputs"
WORK = BASE / "work"
OUTPUT.mkdir(exist_ok=True)
WORK.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-for-production")
MAX_UPLOAD_MB = 15
ALLOWED_AUDIO = {".mp3", ".wav", ".m4a", ".aac", ".ogg"}

def get_font(size, bold=False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf"
    ]
    for p in candidates:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()

def wrap_text(draw, text, font, max_width):
    words = text.split()
    lines, line = [], ""
    for word in words:
        test = (line + " " + word).strip()
        if draw.textbbox((0, 0), test, font=font)[2] <= max_width:
            line = test
        else:
            if line:
                lines.append(line)
            line = word
    if line:
        lines.append(line)
    return lines

def make_scene_image(title, caption, path, index, total, size=(1280, 720)):
    w, h = size
    img = Image.new("RGB", size)
    px = img.load()
    # A simple generated gradient background; no external image API or paid model.
    for y in range(h):
        for x in range(w):
            t = (x / w + y / h) / 2
            px[x, y] = (int(10 + 20*t), int(22 + 35*t), int(48 + 90*t))
    draw = ImageDraw.Draw(img, "RGBA")
    draw.ellipse((w-390, -180, w+120, 330), fill=(45, 130, 220, 45))
    draw.ellipse((-180, h-260, 330, h+180), fill=(100, 70, 210, 35))
    draw.rounded_rectangle((70, 65, w-70, h-65), radius=30, outline=(255,255,255,65), width=2)
    small = get_font(24, True)
    heading = get_font(58, True)
    body = get_font(34)
    draw.text((110, 100), "PROMPT2VIDEO AI", font=small, fill=(130, 205, 255, 255))
    draw.text((w-240, 100), f"{index+1:02d} / {total:02d}", font=small, fill=(220,230,245,220))
    title_lines = wrap_text(draw, title, heading, w-220)[:3]
    y = 220
    for line in title_lines:
        draw.text((110, y), line, font=heading, fill=(255,255,255,255))
        y += 78
    caption_lines = wrap_text(draw, caption, body, w-240)[:3]
    y = min(max(y+25, 465), 540)
    for line in caption_lines:
        draw.text((115, y), line, font=body, fill=(205,220,240,255))
        y += 48
    draw.rounded_rectangle((110, h-135, 360, h-122), radius=6, fill=(90,180,255,220))
    img.save(path, quality=92)

def build_story(prompt, language):
    # Lightweight prompt-to-storyboard fallback. This creates an editable text-led video,
    # not photorealistic AI-generated footage.
    clean = " ".join(prompt.split())
    if language == "Hindi":
        intro = f"आज हम जानेंगे: {clean}।"
        beats = [
            f"{clean} को समझना क्यों जरूरी है?",
            "सबसे पहले इसकी मुख्य बातों पर ध्यान दें।",
            "छोटे-छोटे कदम बेहतर परिणाम बनाने में मदद करते हैं।",
            "जानकारी को समझें और उसे सही तरीके से लागू करें।",
            "याद रखें: सीखते रहें और आगे बढ़ते रहें।"
        ]
        titles = ["आज का विषय", "यह क्यों जरूरी है?", "मुख्य बातें", "इसे कैसे अपनाएं", "अंतिम संदेश"]
        voice_text = " ".join([intro] + beats)
    else:
        intro = f"Today, let's explore: {clean}."
        beats = [
            f"Why does {clean} matter?",
            "Start by understanding the most important ideas.",
            "Small, consistent steps can lead to better results.",
            "Use what you learn in a practical and thoughtful way.",
            "Keep learning, improving, and moving forward."
        ]
        titles = ["Today's topic", "Why it matters", "Key ideas", "Put it into action", "Final thought"]
        voice_text = " ".join([intro] + beats)
    scenes = [(titles[0], intro)] + list(zip(titles[1:], beats))
    return scenes, voice_text

async def create_voice(text, output_path, voice):
    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(str(output_path))

def run_ffmpeg(args):
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    proc = subprocess.run([ffmpeg, "-y"] + args, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr[-1800:])
    return proc

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        prompt = request.form.get("prompt", "").strip()
        language = request.form.get("language", "English")
        if not prompt:
            flash("Please enter a prompt.")
            return redirect(url_for("index"))
        if len(prompt) > 700:
            flash("Please keep your prompt under 700 characters.")
            return redirect(url_for("index"))

        job = uuid.uuid4().hex[:12]
        job_dir = WORK / job
        job_dir.mkdir(parents=True, exist_ok=True)
        out_name = f"{job}.mp4"
        out_path = OUTPUT / out_name

        try:
            scenes, narration = build_story(prompt, language)
            image_paths = []
            for i, (title, caption) in enumerate(scenes):
                p = job_dir / f"scene_{i:02d}.png"
                make_scene_image(title, caption, p, i, len(scenes))
                image_paths.append(p)

            # Voice is free-to-use through the Edge TTS endpoint, but requires internet.
            voice = "hi-IN-SwaraNeural" if language == "Hindi" else "en-US-JennyNeural"
            audio_path = job_dir / "voice.mp3"
            try:
                asyncio.run(create_voice(narration, audio_path, voice))
                voice_status = "AI voice generated."
            except Exception:
                audio_path = None
                voice_status = "Voice service was unavailable; video was created without narration."

            # Use a concat file with equal scene duration; -shortest trims to narration length.
            concat_path = job_dir / "frames.txt"
            duration = 4
            with open(concat_path, "w", encoding="utf-8") as f:
                for p in image_paths:
                    f.write(f"file '{p.as_posix()}'\n")
                    f.write(f"duration {duration}\n")
                f.write(f"file '{image_paths[-1].as_posix()}'\n")

            args = ["-f", "concat", "-safe", "0", "-i", str(concat_path)]
            if audio_path and audio_path.exists():
                args += ["-i", str(audio_path)]
            args += ["-vf", "scale=1280:720,format=yuv420p", "-r", "25",
                     "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p"]
            if audio_path and audio_path.exists():
                args += ["-c:a", "aac", "-b:a", "128k", "-shortest"]
            else:
                args += ["-an"]
            args += [str(out_path)]
            run_ffmpeg(args)
            return render_template("result.html", filename=out_name, voice_status=voice_status,
                                   prompt=prompt, language=language)
        except Exception as e:
            flash("Could not create video. " + str(e)[:500])
            return redirect(url_for("index"))
    return render_template("index.html")

@app.route("/download/<filename>")
def download(filename):
    if not filename.endswith(".mp4") or "/" in filename or "\\" in filename:
        return "Invalid file", 400
    return send_from_directory(OUTPUT, filename, as_attachment=True)

@app.route("/health")
def health():
    return {"status": "ok", "app": "Prompt2Video AI"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
